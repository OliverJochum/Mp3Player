package scenes.playerview;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.Main;
import businesslogik.Player;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import uicomponents.ControlViewController;
import uicomponents.CoverViewController;
import uicomponents.ProgressViewController;

public class PlayerViewController extends BorderPane{
	private Main application;
	private Pane root;
	
	private Player player;
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Pane coverPane;
    
    @FXML
    private Pane progressPane;
    
    @FXML
    private Pane controlPane;
    
    @FXML
    private ControlViewController controlView;
    
    @FXML
    private ProgressViewController progressView;
    
    @FXML
    private CoverViewController coverView;

	//PlayerViewController acts as both the root and the controller of the scene
    
    public PlayerViewController(Main application, Player player) {
    	this.application = application;
    	this.player = player;
    	
    	FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("PlayerView.fxml"));
    	
    	fxmlLoader.setRoot(this);
    	fxmlLoader.setController(this);
    	
    	try {
    		fxmlLoader.load();
    		
    	}catch(IOException e) {
    		throw new RuntimeException(e);
    	}
    	
    }
    
    @FXML
    void initialize() {
        controlView.getPlaypauseButton().addEventHandler(ActionEvent.ACTION, e -> startPlayer());

    }
    
    private void startPlayer() {
    	player.play();
    }
    
    private void pausePlayer() {
    	player.pause();
    }
}


