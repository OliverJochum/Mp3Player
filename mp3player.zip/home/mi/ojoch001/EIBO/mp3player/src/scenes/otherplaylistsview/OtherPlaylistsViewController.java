package scenes.otherplaylistsview;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class OtherPlaylistsViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    

    public OtherPlaylistsViewController() {
    	
    }
    
    @FXML
    void initialize() {
        

    }
}
