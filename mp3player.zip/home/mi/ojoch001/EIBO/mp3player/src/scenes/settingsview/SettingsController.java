package scenes.settingsview;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class SettingsController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    

    public SettingsController() {
    	
    }
    
    @FXML
    void initialize() {
        

    }
}
