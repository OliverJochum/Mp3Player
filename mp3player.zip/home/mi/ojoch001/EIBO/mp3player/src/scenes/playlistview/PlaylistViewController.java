package scenes.playlistview;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class PlaylistViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    

    public PlaylistViewController() {
    	
    }
    
    @FXML
    void initialize() {
        

    }
}
