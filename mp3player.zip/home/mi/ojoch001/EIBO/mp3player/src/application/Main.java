package application;
	
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import businesslogik.Player;
import de.hsrm.mi.prog.util.StaticScanner;
import javafx.application.Application;
import javafx.stage.Stage;
import scenes.playerview.PlayerView;
import scenes.playerview.PlayerViewController;
import scenes.playlistview.PlaylistView;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	Player player;
	Map<String, Pane> scenes;
	@Override
	public void start(Stage primaryStage) throws IOException{
//		FXMLLoader loader = new FXMLLoader();
//		
//		String fxmlDocPath = "/home/mi/ojoch001/eclipse-workspace/mp3player/src/scenes/playerview/PlayerView.fxml";
//		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
//		
//		BorderPane root = (BorderPane) loader.load(fxmlStream);
//		
//		
//		Scene scene = new Scene(root);
//		
//		primaryStage.setScene(scene);
//		
//		primaryStage.setTitle("PlayerView");
//
//		primaryStage.show();
		
		try {
			player = new Player();
			
			scenes = new HashMap<String, Pane>();
			
			Pane view = new PlayerViewController(this,player);
			scenes.put("PlayerView", view);
			
			view = new PlaylistView();
			scenes.put("PlaylistView", view);
			
			Pane root;
			
			System.out.println("Which scene would you like?");
			
			String sceneSelect = StaticScanner.nextString();
			
			try {
				root = scenes.get(sceneSelect);
				
				Scene scene = new Scene(root,400,600);
				
				primaryStage.setScene(scene);
				primaryStage.show();			
				
			}catch(NullPointerException npe) {
				System.out.println("Root cannot be null. Please enter a valid scene name");
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		launch(args);
		
	}
	
	
}
