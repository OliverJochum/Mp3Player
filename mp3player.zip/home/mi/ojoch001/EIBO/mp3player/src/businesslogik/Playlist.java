package businesslogik;

import java.util.ArrayList;


public class Playlist {
	private String name;
	private ArrayList<Track> tracklist;
	
	public Playlist(String name) {
		this.name = name;
		
		tracklist = new ArrayList<Track>();
	}
	
	public ArrayList<Track> getTracklist(){
		return tracklist;
	}
	
	public String getName() {
		return name; 
	}
	
	public void addTrack(String title) {
		tracklist.add(new Track(title));
	}
	
	public Track getTrack(String title) {
		for(Track track : tracklist) {
			if(title.equals(track.getTitle())) {
				return track;
			}
		} 
		return null;
	}
	
	public void skip(Track current) {
		Track t = getTrack(current.getTitle());

		for (Track track : tracklist) {
			if (t.equals(track)) {
				int index = tracklist.indexOf(track);
				tracklist.get(index).setSelected(false);
				if (index == tracklist.size() - 1) {
					tracklist.get(0).setSelected(true);
				} else {
					tracklist.get(index + 1).setSelected(true);
				}
			}
		}
	}

	public void skipb(Track current) {
		Track t = getTrack(current.getTitle());

		for (Track track : tracklist) {
			if (t.equals(track)) {
				int index = tracklist.indexOf(track);
				tracklist.get(index).setSelected(false);
				if (index == 0) {
					tracklist.get(tracklist.size() - 1);
				} else {
					tracklist.get(index - 1).setSelected(true);
				}
			}
		}
	}
}

