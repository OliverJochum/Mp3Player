package businesslogik;

import de.hsrm.mi.eibo.simpleplayer.SimpleAudioPlayer;
import de.hsrm.mi.eibo.simpleplayer.SimpleMinim;
import java.util.*;

public class Player {
	private SimpleMinim minim;
	private SimpleAudioPlayer audioPlayer;
	
	public Player() {
		minim = new SimpleMinim(true);
	}
	
	public void play() {
		audioPlayer = minim.loadMP3File("/home/mi/ojoch001/EIBO/01_Bring_Mich Nach_Hause.mp3");
		audioPlayer.play();
	}
	
	public void play(String fileName) {
		System.out.println("Playing " + fileName);
		audioPlayer = minim.loadMP3File(fileName);
	}
	
	public void pause() {
		audioPlayer.pause();
	}
	
	public void volume(float value) {
		audioPlayer.setVolume(value);
	}
	
	//Shuffle
	public void shuffle(Playlist playlist, boolean on) {
		Collections.shuffle(playlist.getTracklist());
	}
	//Repeat
	public void repeat(boolean on) {
		if(on) {
			audioPlayer.loop();			
		}
		else {
			audioPlayer.loop(0);
		}
	}
	
	public int getPosition() {
		return audioPlayer.position();
	}
	
	public int getEndTime() {
		return audioPlayer.length();
	}
	
}
