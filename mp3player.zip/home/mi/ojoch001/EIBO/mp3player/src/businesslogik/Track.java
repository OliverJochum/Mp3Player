package businesslogik;
import java.io.IOException;

import com.mpatric.mp3agic.*;


public class Track {
	private Mp3File mp3file;
	private String title;
	private String track;
	private String album;
	private String artist;
	private String path;
	private boolean selected;
	
	public Track(String title) {
		this.title = title;
		
		try {
			mp3file = new Mp3File(title);
			if(mp3file.hasId3v1Tag()) {
				ID3v1 id3v1Tag = mp3file.getId3v1Tag();
				this.track = id3v1Tag.getTrack();
				this.album = id3v1Tag.getAlbum();
				this.artist = id3v1Tag.getArtist();
				this.path = "/home/mi/ojoch001/EIBO/" + title;
			}
		} catch (UnsupportedTagException|InvalidDataException|IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
		
	}
	
	public Mp3File getMp3File() {
		return mp3file;
	}
	
	public boolean isSelected() {
		return selected;
	}



	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTrack() {
		return track;
	}

	public void setTrack(String track) {
		this.track = track;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	
	
	
	
}