package businesslogik;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class PlaylistManager {
	
	public PlaylistManager() {
		
	}
	
	public Playlist getPlaylist(String name) {
		//default
		String fileName = "/home/mi/ojoch001/EIBO/default.m3u";
		Playlist playlist = new Playlist(name);
		
		try(BufferedReader br = new BufferedReader(new FileReader(fileName))){
			String line;
			while((line = br.readLine()) != null) {
				playlist.addTrack(line);
				System.out.println(playlist.getTrack(playlist.getTrack(line).getTitle()));
			} 
		}catch(IOException e) {
			e.printStackTrace();
		}
	
		return playlist;
		
	}
	
	
}
